#define _GNU_SOURCE
#include <sched.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/mman.h>
#include <sys/resource.h>
#include <string.h>
#include <time.h>
#include <errno.h>
#include <signal.h>
#include <dirent.h>
#include <sys/wait.h>
#include <sys/syscall.h>
#include <errno.h>
#include <stdint.h>

int status;
int pid[21];

void calculate(); // process 가 실행할 계산하는 함수

int main()
{
    cpu_set_t set;
    CPU_ZERO(&set);    // CPU 코어 집합 초기화
    CPU_SET(0, &set);  // CPU 코어 0을 추가 (다른 코어를 추가하려면 여러 번 호출)

    if (sched_setaffinity(getpid(), sizeof(cpu_set_t), &set) == -1) { // CPU 코어 개수 제한
        perror("Error setting CPU affinity");
        return 1;
    }

    for(int i = 0 ; i < 21 ; i++){

        if((pid[i] = fork()) < 0) { // 자식 프로세스 생성
            printf("fork error\n");
            exit(1);
        }
        else if(pid[i] == 0) {
            
            calculate();

            exit(0);
        }
    }

    for(int i = 0 ; i < 21 ; i++) {
        pid_t wpid = waitpid(pid[i],&status,0); // 자식 프로세스 종료 상태를 회수
    }

}

// process 가 실행할 계산하는 함수
void calculate() {
    int count = 0, k, i, j;
    int result[100][100], A[100][100], B[100][100];

    memset(result, 0, sizeof(result));
    memset(A, 0, sizeof(A));
    memset(B, 0, sizeof(B));

    while(count < 100){
        for(k = 0; k < 100; k++){
            for(i = 0; i < 100; i++) {
                for(j = 0; j < 100; j++) {
                    result[k][j] += A[k][i] * B[i][j];
                }
            }
        }
        count++;
    }
}

